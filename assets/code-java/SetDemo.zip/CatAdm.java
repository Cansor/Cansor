//package com.spellbk.SetDemo;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * 猫类的管理类
 * @author Cansor
 *
 */
class CatAdm implements Serializable {
	Set<Cat> s;

	public CatAdm() {
		s = new HashSet<Cat>();
	}

	//添加
	public boolean add(Cat c) {
		if(c.getName() == null) {
			return false;
		}
		return s.add(c);
	}
	
	//删除
	public boolean del(String name) {
		if(name == null) {
			return false;
		}
		Cat c = find(name);
		return s.remove(c);
	}
	
	//修改
	public void mod(Cat c) {
		if(c.getName() == null) {
			return;
		}

		Cat cat = find(c.getName());
		cat.setAge(c.getAge());
	}
	
	//查找
	public Cat find(String name) {
		if(name == null) {
			return null;
		}
		
		Cat[] cat = s.toArray(new Cat[]{});//转换为数组		
		//遍历数组，名字相同则返回对象，否则返回null
		for (Cat c : cat) {
			if(name.equals(c.getName())) return c;
		}
		return null;
	}
	
	//输出信息
	public void print() {
		System.out.println("\n目前有"+s.size()+"只猫。");
	}
	
	public void prints() {
		System.out.println(s);
	}
}
