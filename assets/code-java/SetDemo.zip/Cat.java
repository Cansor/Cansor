//package com.spellbk.SetDemo;
/**
 * 猫类
 * @author Cansor
 *
 */
public class Cat {
	private String name;//名字
	private int age;//年龄
	
	//构造方法
	public Cat(String name, int age) {
		this.name = name;
		this.age = age;
	}
	public Cat() {
	}
	
	//读写方法
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	/**
	 * 重写hashCode和equals方法
	 */
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}
	
	//按照名字来判断对象是否重复
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cat other = (Cat) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	
	public String toString() {
		return "Cat [name=" + name + ", age=" + age + "]\n";
	}
}
