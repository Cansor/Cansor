//package com.spellbk.SetDemo;

import java.util.Scanner;

/**
 * 使用Set集合模拟数据库的增删改查操作
 * @author Cansor
 *
 */

public class SetDemo {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		CatAdm ca = new CatAdm();

		while(true) {
			ca.print();
			
			System.out.println("\n1、增加  2、删除  3、修改  4、查找  5、查看所有");
			int i = input.nextInt();
			
			switch (i) {
			case 1:
				input = new Scanner(System.in);
				System.out.println("输入名字：");
				String name = input.nextLine();
				System.out.println("输入年龄：");
				int age = input.nextInt();
				
				if(ca.add(new Cat(name, age))) {
					System.out.println("添加成功！");
				}else {
					System.out.println("添加失败！");
				}
				break;
				
			case 2:
				input = new Scanner(System.in);
				System.out.println("输入名字：");
				name = input.nextLine();
				if(ca.del(name)) {
					System.out.println("删除成功！");
				}else {
					System.out.println("删除失败！");
				}
				break;
				
			case 3:
				input = new Scanner(System.in);
				System.out.println("要修改谁：");
				name = input.nextLine();
				System.out.println("将年龄改成：");
				age = input.nextInt();
				ca.mod(new Cat(name,age));
				break;
				
			case 4:
				input = new Scanner(System.in);
				System.out.println("要查找谁：");
				name = input.nextLine();
				System.out.println(ca.find(name));
				break;
				
			default:
				ca.prints();
				break;
			}
		}
	}
}
